extends RefCounted

const Legacy = preload("res://scripts/trial_encounter.gd")
static var _definition: Dictionary = {}
static var _veil: Dictionary = {}
static func points(region_id: String = "jade") -> Array:
	if _definition.is_empty(): _definition = JSON.parse_string(FileAccess.get_file_as_string("res://data/jade_route.json"))
	if _veil.is_empty(): _veil = JSON.parse_string(FileAccess.get_file_as_string("res://data/veil_route.json"))
	return (_veil.points if region_id == "veil" else _definition.points).duplicate(true)
static func region_for(id: String) -> String:
	for region_id in ["jade", "veil"]:
		for entry in points(region_id):
			if entry.id == id: return region_id
	return ""
static func point(id: String) -> Dictionary:
	var region_id: = region_for(id)
	if region_id.is_empty(): return {}
	for entry in points(region_id):
		if entry.id == id: return entry
	return {}
static func entry_cost(id: String) -> int: return int(point(id).get("cost", 0))
static func defaults() -> Dictionary:
	return {"schema": 1, "completed": [], "current": {}, "selected": "jade", "regions": {"veil": {"completed": []}}}
static func normalized(data: Dictionary) -> Dictionary:
	var result: = data.duplicate(true)
	result.schema = 1
	if not result.has("selected"): result.selected = "jade"
	if not result.has("regions"): result.regions = {"veil": {"completed": []}}
	return result
static func completions(data: Dictionary, region_id: String = "jade") -> Array:
	return data.completed if region_id == "jade" else data.get("regions", {}).get(region_id, {}).get("completed", [])
static func completed(data: Dictionary, id: String) -> bool:
	for entry in completions(data, region_for(id)):
		if entry.point_id == id: return true
	return false
static func unlocked(data: Dictionary, id: String) -> bool:
	var region_id: = region_for(id)
	if region_id.is_empty(): return false
	for entry in points(region_id):
		if entry.id == id: return true
		if not completed(data, entry.id): return false
	return false
static func next_point(data: Dictionary, region_id: String = "") -> String:
	if region_id.is_empty(): region_id = data.get("selected", "jade")
	for entry in points(region_id):
		if not completed(data, entry.id): return entry.id
	return ""
static func encounter_id_valid(id: Variant, sequence: int) -> bool:
	if not id is String or not id.begins_with("jade-"): return false
	var suffix: String = id.trim_prefix("jade-")
	return suffix.is_valid_int() and int(suffix) > 0 and int(suffix) <= sequence and id == "jade-%d" % int(suffix)
static func valid(data: Variant, campaign: Dictionary) -> bool:
	if not data is Dictionary or data.get("schema") != 1 or not data.get("completed") is Array or not data.get("current") is Dictionary: return false
	if data.get("selected", "jade") not in ["jade", "veil"]: return false
	if data.has("regions"):
		if not data.regions is Dictionary: return false
		for id in data.regions:
			if id != "veil" or not data.regions[id] is Dictionary or not data.regions[id].get("completed") is Array: return false
	var ids: = {}
	var count: = 0
	for region_id in ["jade", "veil"]:
		var entries: = completions(data, region_id)
		if entries.size() > points(region_id).size(): return false
		count += entries.size()
		for i in range(entries.size()):
			var entry: Variant = entries[i]
			if not entry is Dictionary or entry.get("point_id") != points(region_id)[i].id or not encounter_id_valid(entry.get("encounter_id"), int(campaign.sequence)) or ids.has(entry.encounter_id): return false
			ids[entry.encounter_id] = true
	if count > campaign.victories: return false
	if data.current.is_empty(): return true
	var current: Dictionary = data.current
	if not current.get("point_id") is String or not unlocked(data, current.point_id) or point(current.point_id).is_empty(): return false
	var encounter: Dictionary = campaign.encounter
	if encounter.is_empty() or current.get("encounter_id") != encounter.get("id"): return false
	var selected: = point(current.point_id)
	if encounter.has("regional"):
		if encounter.regional.point_id != current.point_id or encounter.regional.region != region_for(current.point_id): return false
		if encounter.enemy_team[0].species_id != selected.species: return false
	elif encounter.get("enemy_species") != selected.species: return false
	var won: bool = encounter.get("phase") in ["capture", "captured", "escaped"]
	for region_id in ["jade", "veil"]:
		for entry in completions(data, region_id):
			if entry.encounter_id == encounter.id and ( not won or entry.point_id != current.point_id): return false
	if won and not completed(data, current.point_id): return false
	return true
static func record_victory(data: Dictionary, encounter_id: String) -> Dictionary:
	var result: = normalized(data)
	if result.current.get("encounter_id") != encounter_id: return result
	var id: String = result.current.point_id
	if not completed(result, id) and unlocked(result, id):
		completions(result, region_for(id)).append({"point_id": id, "encounter_id": encounter_id})
	return result
